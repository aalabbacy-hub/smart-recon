#!/usr/bin/env bash
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
DEFAULT_CMD="recon-en"

printf '==============================================
'
printf '         Recon-EN v5 Installer
'
printf '==============================================
'

for f in recon-en config.toml abd_recon/__init__.py abd_recon/cli.py; do
  [[ -f "$SCRIPT_DIR/$f" ]] || { echo "Missing: $f"; exit 1; }
done

chmod +x "$SCRIPT_DIR/recon-en" "$SCRIPT_DIR/abd-recon" "$SCRIPT_DIR/installer.sh"
read -rp "Command name [$DEFAULT_CMD]: " CMD_NAME
CMD_NAME="${CMD_NAME:-$DEFAULT_CMD}"
TARGET="/usr/local/bin/$CMD_NAME"
if [[ -e "$TARGET" || -L "$TARGET" ]]; then
  read -rp "Overwrite existing $TARGET ? (y/n): " ans
  [[ "$ans" =~ ^[Yy]$ ]] || exit 1
  sudo rm -f "$TARGET"
fi
sudo ln -s "$SCRIPT_DIR/recon-en" "$TARGET"
echo
echo "Installed: $TARGET"
echo "Run with: $CMD_NAME"
echo "When you type only the command name, the interactive menu opens automatically."
