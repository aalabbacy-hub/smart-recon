# Recon-EN v6

Professional authorized recon and exposure-validation framework.

## What is new in v6
- Default command name remains `recon-en`
- Interactive menu still opens automatically when you type only `recon-en`
- Improved local dashboard report with sections, badges, metrics, tables, and event timeline
- `dashboard` command to serve any results folder locally in the browser
- Better HTML reporting with findings grouped by severity
- Preserves SQLite + JSON + CSV + HTML reporting
- Scope-file batch scanning still supported

## Install
```bash
chmod +x installer.sh
./installer.sh
```

## Run
```bash
recon-en
recon-en scan example.com
recon-en passive example.com
recon-en active https://example.com
recon-en users example.com
recon-en scan examples/scope.txt
recon-en dashboard output/example.com_YYYY-MM-DD_HH-MM-SS
```

## Notes
This package is for authorized reconnaissance and exposure validation only.
It does not include exploitation, payload delivery, persistence, credential attacks, or attack automation.
