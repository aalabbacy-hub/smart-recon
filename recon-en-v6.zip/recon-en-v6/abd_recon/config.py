from __future__ import annotations
from pathlib import Path
import tomllib

DEFAULTS = {
    'tool_name': 'Recon-EN',
    'tool_cmd': 'recon-en',
    'version': 'v5.0',
    'outbase': 'output',
    'threads': 40,
    'timeout': 10,
    'http_retries': 2,
    'http_backoff': 0.5,
    'cache_ttl_seconds': 21600,
    'enable_cache': True,
    'user_agent': 'Recon-EN/5.0 (Authorized Recon Platform)',
    'strict_scope': True,
    'max_urls': 300,
    'enable_crtsh': True,
    'enable_html': True,
    'enable_json': True,
    'enable_csv': True,
    'enable_sqlite': True,
    'enable_whois': True,
    'enable_nslookup': True,
    'enable_dig': True,
    'enable_http_probe': True,
    'enable_whatweb': True,
    'enable_waf': True,
    'enable_wp_users': True,
    'enable_wpscan': True,
    'enable_external_subs': True,
}

def load_config(base_dir: Path) -> dict:
    cfg = dict(DEFAULTS)
    path = base_dir / 'config.toml'
    if path.exists():
        with path.open('rb') as f:
            data = tomllib.load(f)
        cfg.update(data)
    return cfg
