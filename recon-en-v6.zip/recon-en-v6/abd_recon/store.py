from __future__ import annotations
from pathlib import Path
import sqlite3

SCHEMA = [
    'create table if not exists session_meta (k text primary key, v text)',
    'create table if not exists findings (severity text, title text, evidence text)',
    'create table if not exists metrics (k text primary key, v text)',
    'create table if not exists urls (url text primary key, status text, title text, tech text)',
    'create table if not exists subdomains (name text primary key)',
    'create table if not exists users (username text, display_name text, link text)',
    'create table if not exists artifacts (kind text, path text)',
]

class Store:
    def __init__(self, db_path: Path):
        self.conn = sqlite3.connect(db_path)
        for stmt in SCHEMA:
            self.conn.execute(stmt)
        self.conn.commit()

    def set_meta(self, k: str, v: str) -> None:
        self.conn.execute('insert or replace into session_meta(k,v) values(?,?)', (k, v))
        self.conn.commit()

    def set_metric(self, k: str, v: str) -> None:
        self.conn.execute('insert or replace into metrics(k,v) values(?,?)', (k, v))
        self.conn.commit()

    def add_finding(self, severity: str, title: str, evidence: str) -> None:
        self.conn.execute('insert into findings(severity,title,evidence) values(?,?,?)', (severity, title, evidence))
        self.conn.commit()

    def add_url(self, url: str, status: str = '', title: str = '', tech: str = '') -> None:
        self.conn.execute('insert or replace into urls(url,status,title,tech) values(?,?,?,?)', (url, status, title, tech))
        self.conn.commit()

    def add_subdomain(self, name: str) -> None:
        self.conn.execute('insert or ignore into subdomains(name) values(?)', (name,))
        self.conn.commit()

    def add_user(self, username: str, display_name: str, link: str) -> None:
        self.conn.execute('insert into users(username,display_name,link) values(?,?,?)', (username, display_name, link))
        self.conn.commit()

    def add_artifact(self, kind: str, path: str) -> None:
        self.conn.execute('insert into artifacts(kind,path) values(?,?)', (kind, path))
        self.conn.commit()

    def list_rows(self, query: str) -> list[tuple]:
        return list(self.conn.execute(query))
