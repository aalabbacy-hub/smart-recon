from __future__ import annotations
from pathlib import Path
from urllib.parse import urlparse
import csv
import html
import ipaddress
import json
import re
import shutil
import subprocess
import requests
from requests.adapters import HTTPAdapter
from urllib3.util.retry import Retry

DOMAIN_RE = re.compile(r'^(?!-)(?:[A-Za-z0-9-]{1,63}\.)+[A-Za-z]{2,63}$')
EMAIL_RE = re.compile(r'^[^@\s]+@[^@\s]+\.[^@\s]+$')


def have(tool: str) -> bool:
    return shutil.which(tool) is not None


def run_command(args: list[str], timeout: int = 60) -> tuple[int, str, str]:
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout)
        return p.returncode, p.stdout, p.stderr
    except Exception as exc:
        return 1, '', str(exc)


def build_session(user_agent: str, retries: int = 2, backoff: float = 0.5) -> requests.Session:
    session = requests.Session()
    retry = Retry(
        total=retries,
        connect=retries,
        read=retries,
        backoff_factor=backoff,
        status_forcelist=(429, 500, 502, 503, 504),
        allowed_methods=frozenset(['HEAD', 'GET', 'OPTIONS']),
        raise_on_status=False,
    )
    adapter = HTTPAdapter(max_retries=retry, pool_connections=20, pool_maxsize=20)
    session.mount('http://', adapter)
    session.mount('https://', adapter)
    session.headers.update({'User-Agent': user_agent})
    return session


def classify_target(raw: str) -> tuple[str, str, str | None]:
    raw = raw.strip()
    p = Path(raw)
    if p.exists() and p.is_file():
        return 'file', str(p.resolve()), None
    if raw.startswith(('http://', 'https://')):
        parsed = urlparse(raw)
        host = (parsed.hostname or '').strip()
        return 'url', host or raw, raw
    if EMAIL_RE.match(raw):
        return 'email', raw.lower(), None
    try:
        ipaddress.ip_address(raw)
        return 'ip', raw, None
    except ValueError:
        pass
    if DOMAIN_RE.match(raw):
        return 'domain', raw.lower(), f'https://{raw.lower()}'
    raise ValueError(f'Unsupported target format: {raw}')


def jsonl_append(path: Path, obj: dict) -> None:
    with path.open('a', encoding='utf-8') as f:
        f.write(json.dumps(obj, ensure_ascii=False) + '\n')


def safe_slug(value: str) -> str:
    return re.sub(r'[^A-Za-z0-9_.-]+', '_', value)


def read_scope_file(path: Path) -> list[str]:
    items = []
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = line.strip()
        if not line or line.startswith('#'):
            continue
        items.append(line)
    return sorted(set(items))


def write_csv(path: Path, rows: list[dict]) -> None:
    if not rows:
        path.write_text('', encoding='utf-8')
        return
    with path.open('w', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def escape(s: str) -> str:
    return html.escape(s, quote=True)
