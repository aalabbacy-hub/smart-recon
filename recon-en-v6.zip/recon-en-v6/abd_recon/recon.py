from __future__ import annotations
from pathlib import Path
from urllib.parse import urlparse
import json
import urllib3
from .utils import classify_target, have, read_scope_file, run_command, build_session
from .context import SessionContext
from .reporting import generate_reports
from .cache import FileCache

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)


class ReconApp:
    def __init__(self, base_dir: Path, config: dict):
        self.base_dir = base_dir
        self.config = config
        self.http = build_session(
            self.config['user_agent'],
            retries=int(self.config.get('http_retries', 2)),
            backoff=float(self.config.get('http_backoff', 0.5)),
        )
        self.cache = FileCache(
            self.base_dir / '.cache',
            ttl_seconds=int(self.config.get('cache_ttl_seconds', 21600)),
        )

    def banner(self) -> str:
        return (
            '==================================================\n'
            f"  {self.config['tool_name']} {self.config['version']}\n"
            '==================================================\n'
            'Mode: Authorized Recon / Exposure Validation\n'
            f"Command: {self.config['tool_cmd']}\n"
        )

    def create_session(self, target_input: str) -> SessionContext:
        kind, normalized, base_url = classify_target(target_input)
        return SessionContext(self.base_dir, self.config, target_input, kind, normalized, base_url)

    def dependency_report(self) -> list[tuple[str, bool]]:
        tools = ['python3', 'curl', 'jq', 'whois', 'dig', 'nslookup', 'httpx', 'whatweb', 'wafw00f', 'subfinder', 'assetfinder', 'amass', 'wpscan']
        return [(tool, have(tool)) for tool in tools]

    def scan(self, target_input: str) -> SessionContext:
        ctx = self.create_session(target_input)
        ctx.event('session', 'scan_started')
        self.run_passive(ctx)
        self.run_active(ctx)
        self.run_users(ctx)
        generate_reports(ctx)
        ctx.event('session', 'scan_finished')
        return ctx

    def _fetch_text(self, url: str, timeout: int | None = None, allow_redirects: bool = True) -> str:
        cache_key = f'GET:{url}'
        if self.config.get('enable_cache'):
            cached = self.cache.get(cache_key)
            if cached is not None:
                return str(cached)
        r = self.http.get(url, timeout=timeout or self.config['timeout'], verify=False, allow_redirects=allow_redirects)
        text = r.text
        if self.config.get('enable_cache') and r.ok:
            self.cache.set(cache_key, text)
        return text

    def _fetch_json(self, url: str, timeout: int | None = None):
        cache_key = f'JSON:{url}'
        if self.config.get('enable_cache'):
            cached = self.cache.get(cache_key)
            if cached is not None:
                return cached
        r = self.http.get(url, timeout=timeout or self.config['timeout'], verify=False, allow_redirects=True)
        data = r.json()
        if self.config.get('enable_cache') and r.ok:
            self.cache.set(cache_key, data)
        return data

    def scan_scope_file(self, path: str) -> Path:
        items = read_scope_file(Path(path))
        root = self.base_dir / self.config['outbase'] / ('scope_batch_' + Path(path).stem)
        root.mkdir(parents=True, exist_ok=True)
        summary_lines = [f'Scope file: {path}', f'Items: {len(items)}', '']
        for item in items:
            try:
                ctx = self.scan(item)
                summary_lines.append(f'[OK] {item} -> {ctx.outdir}')
            except Exception as exc:
                summary_lines.append(f'[ERR] {item} -> {exc}')
        (root / 'batch_summary.txt').write_text('\n'.join(summary_lines), encoding='utf-8')
        return root

    def run_passive(self, ctx: SessionContext) -> None:
        ctx.event('passive', 'started')
        target_host = ctx.normalized_target
        if ctx.target_kind == 'email':
            target_host = ctx.normalized_target.split('@', 1)[1]
            (ctx.outdir / 'input' / 'email_domain.txt').write_text(target_host, encoding='utf-8')
            ctx.finding('info', 'Email domain extracted', target_host)
        if ctx.target_kind == 'file':
            items = read_scope_file(Path(ctx.target_input))
            (ctx.outdir / 'input' / 'scope_items.txt').write_text('\n'.join(items), encoding='utf-8')
            ctx.store.set_metric('scope_items', str(len(items)))
            ctx.event('passive', 'scope_file_loaded', count=len(items))
            return
        if ctx.target_kind in {'domain', 'url', 'email'}:
            if ctx.target_kind == 'url' and ctx.base_url:
                p = urlparse(ctx.base_url)
                target_host = p.hostname or ctx.normalized_target
            if self.config.get('enable_whois') and have('whois'):
                rc, out, err = run_command(['whois', target_host], timeout=30)
                (ctx.outdir / 'dns' / 'whois.txt').write_text(out or err, encoding='utf-8', errors='ignore')
            if self.config.get('enable_nslookup') and have('nslookup'):
                text = []
                for args in ([target_host], ['-type=mx', target_host], ['-type=ns', target_host]):
                    rc, out, err = run_command(['nslookup', *args], timeout=20)
                    text.append(out or err)
                (ctx.outdir / 'dns' / 'nslookup.txt').write_text('\n\n'.join(text), encoding='utf-8')
            if self.config.get('enable_dig') and have('dig'):
                text = []
                for q in ('A', 'AAAA', 'MX', 'NS', 'TXT'):
                    rc, out, err = run_command(['dig', target_host, q, '+short'], timeout=20)
                    text.append(f'===== {q} =====\n{out or err}')
                (ctx.outdir / 'dns' / 'dig.txt').write_text('\n\n'.join(text), encoding='utf-8')
            subs = {target_host}
            if self.config.get('enable_external_subs'):
                tool_args = {
                    'subfinder': ['subfinder', '-d', target_host, '-silent'],
                    'assetfinder': ['assetfinder', '--subs-only', target_host],
                    'amass': ['amass', 'enum', '-passive', '-d', target_host],
                }
                for tool, args in tool_args.items():
                    if have(tool):
                        rc, out, err = run_command(args, timeout=90)
                        for line in (out or '').splitlines():
                            line = line.strip()
                            if line:
                                subs.add(line)
            if self.config.get('enable_crtsh'):
                try:
                    data = self._fetch_json(f'https://crt.sh/?q=%25.{target_host}&output=json', timeout=20)
                    if isinstance(data, list):
                        for item in data:
                            for name in str(item.get('name_value', '')).splitlines():
                                name = name.replace('*.', '').strip()
                                if name:
                                    subs.add(name)
                except Exception as exc:
                    ctx.event('passive', 'crtsh_failed', error=str(exc))
            sub_list = sorted(subs)
            (ctx.outdir / 'subs' / 'all_subs.txt').write_text('\n'.join(sub_list), encoding='utf-8')
            for sub in sub_list:
                ctx.store.add_subdomain(sub)
            ctx.store.set_metric('subdomains', str(len(sub_list)))
        elif ctx.target_kind == 'ip':
            if self.config.get('enable_whois') and have('whois'):
                rc, out, err = run_command(['whois', ctx.normalized_target], timeout=30)
                (ctx.outdir / 'dns' / 'whois.txt').write_text(out or err, encoding='utf-8')
            if self.config.get('enable_dig') and have('dig'):
                rc, out, err = run_command(['dig', '-x', ctx.normalized_target, '+short'], timeout=20)
                (ctx.outdir / 'dns' / 'reverse_dns.txt').write_text(out or err, encoding='utf-8')
        ctx.event('passive', 'finished')

    def detect_profile(self, ctx: SessionContext) -> str:
        profile = {
            'email': 'mail-domain',
            'ip': 'ip-host',
            'file': 'scope-file',
        }.get(ctx.target_kind, 'generic-web')
        if ctx.target_kind in {'domain', 'url'}:
            url = ctx.base_url or f'https://{ctx.normalized_target}'
            try:
                raw_text = self._fetch_text(url)
                text = raw_text[:6000].lower()
                (ctx.outdir / 'web' / 'homepage_snippet.txt').write_text(raw_text[:6000], encoding='utf-8', errors='ignore')
                if any(x in text for x in ['wp-content', 'wp-includes', 'wordpress', '/wp-json/']):
                    profile = 'wordpress'
                elif any(x in text for x in ['swagger-ui', 'openapi', 'redoc']):
                    profile = 'api-docs'
                elif 'shopify' in text:
                    profile = 'shopify'
                elif 'drupal' in text:
                    profile = 'drupal'
                elif 'joomla' in text:
                    profile = 'joomla'
            except Exception as exc:
                ctx.event('active', 'profile_probe_failed', error=str(exc))
        (ctx.outdir / 'web' / 'target_profile.txt').write_text(profile, encoding='utf-8')
        ctx.store.set_metric('profile', profile)
        return profile

    def run_active(self, ctx: SessionContext) -> None:
        ctx.event('active', 'started')
        profile = self.detect_profile(ctx)
        if ctx.target_kind == 'file':
            ctx.event('active', 'skipped_for_scope_file')
            return
        seeds: list[str] = []
        if ctx.target_kind in {'domain', 'email'}:
            host = ctx.normalized_target.split('@', 1)[1] if ctx.target_kind == 'email' else ctx.normalized_target
            seeds.extend([f'https://{host}', f'http://{host}'])
            subs_path = ctx.outdir / 'subs' / 'all_subs.txt'
            if subs_path.exists():
                for sub in subs_path.read_text(encoding='utf-8', errors='ignore').splitlines():
                    if sub.strip():
                        seeds.extend([f'https://{sub.strip()}', f'http://{sub.strip()}'])
        elif ctx.target_kind == 'url':
            seeds.append(ctx.target_input)
        elif ctx.target_kind == 'ip':
            seeds.extend([f'http://{ctx.normalized_target}', f'https://{ctx.normalized_target}'])
        seeds = list(dict.fromkeys(seeds))[: int(self.config['max_urls'])]
        (ctx.outdir / 'input' / 'seeds.txt').write_text('\n'.join(seeds), encoding='utf-8')

        alive: list[str] = []
        if self.config.get('enable_http_probe') and have('httpx') and seeds:
            rc, out, err = run_command([
                'httpx', '-l', str(ctx.outdir / 'input' / 'seeds.txt'), '-silent', '-status-code', '-title', '-tech-detect',
                '-follow-host-redirects', '-threads', str(self.config['threads']), '-timeout', str(self.config['timeout']), '-json'
            ], timeout=120)
            (ctx.outdir / 'hosts' / 'httpx.json').write_text(out or err, encoding='utf-8', errors='ignore')
            for line in (out or '').splitlines():
                try:
                    obj = json.loads(line)
                except Exception:
                    continue
                url = obj.get('url')
                if not url:
                    continue
                alive.append(url)
                ctx.store.add_url(url, str(obj.get('status_code', '')), str(obj.get('title', '')), ', '.join(obj.get('tech', []) or []))
        else:
            alive = seeds
            for url in alive:
                ctx.store.add_url(url)
        alive = list(dict.fromkeys(alive))
        (ctx.outdir / 'hosts' / 'alive_urls.txt').write_text('\n'.join(alive), encoding='utf-8')
        ctx.store.set_metric('alive_urls', str(len(alive)))

        if alive:
            root_url = alive[0]
            try:
                r = self.http.get(root_url, timeout=self.config['timeout'], verify=False, allow_redirects=True)
                checks = [
                    '===== HEADERS =====\n' + '\n'.join(f'{k}: {v}' for k, v in r.headers.items()),
                    '===== ROBOTS =====\n',
                ]
                try:
                    rr = self.http.get(root_url.rstrip('/') + '/robots.txt', timeout=self.config['timeout'], verify=False)
                    checks.append(rr.text[:4000])
                except Exception as exc:
                    checks.append(str(exc))
                (ctx.outdir / 'web' / 'http_checks.txt').write_text('\n\n'.join(checks), encoding='utf-8', errors='ignore')
            except Exception as exc:
                ctx.event('active', 'http_checks_failed', error=str(exc))

        if self.config.get('enable_whatweb') and have('whatweb') and alive:
            samples = []
            for url in alive[:10]:
                rc, out, err = run_command(['whatweb', url], timeout=30)
                samples.append(f'===== {url} =====\n{out or err}')
            (ctx.outdir / 'web' / 'whatweb.txt').write_text('\n\n'.join(samples), encoding='utf-8')
        if self.config.get('enable_waf') and have('wafw00f') and alive:
            rc, out, err = run_command(['wafw00f', alive[0]], timeout=45)
            (ctx.outdir / 'web' / 'wafw00f.txt').write_text(out or err, encoding='utf-8')
        if profile == 'wordpress':
            ctx.finding('info', 'WordPress profile detected', ctx.normalized_target)
        elif profile == 'api-docs':
            ctx.finding('info', 'API documentation indicators detected', ctx.normalized_target)
        ctx.event('active', 'finished', profile=profile)

    def run_users(self, ctx: SessionContext) -> None:
        ctx.event('users', 'started')
        profile_file = ctx.outdir / 'web' / 'target_profile.txt'
        profile = profile_file.read_text(encoding='utf-8').strip() if profile_file.exists() else 'unknown'
        diag = ctx.outdir / 'wp' / 'users_diagnosis.txt'
        if profile != 'wordpress' or not self.config.get('enable_wp_users'):
            diag.write_text('STATUS: SKIPPED\nREASON: Not classified as WordPress.\n', encoding='utf-8')
            ctx.event('users', 'skipped', profile=profile)
            return
        base = ctx.base_url or f'https://{ctx.normalized_target}'
        url = base.rstrip('/') + '/wp-json/wp/v2/users'
        try:
            text = self._fetch_text(url)
            (ctx.outdir / 'wp' / 'wp_json_users_raw.json').write_text(text, encoding='utf-8', errors='ignore')
            data = json.loads(text) if text.strip().startswith('[') else None
            if isinstance(data, list):
                usernames = []
                pretty = []
                for item in data:
                    username = str(item.get('slug', '')).strip()
                    display_name = str(item.get('name', '')).strip()
                    link = str(item.get('link', '')).strip()
                    if username:
                        usernames.append(username)
                    pretty.append(f'NAME: {display_name} | USERNAME: {username} | LINK: {link}')
                    ctx.store.add_user(username, display_name, link)
                (ctx.outdir / 'wp' / 'public_usernames.txt').write_text('\n'.join(sorted(set(usernames))), encoding='utf-8')
                (ctx.outdir / 'wp' / 'public_users_pretty.txt').write_text('\n'.join(pretty), encoding='utf-8')
                diag.write_text(f'STATUS: OK\nCOUNT: {len(data)}\n', encoding='utf-8')
                ctx.store.set_metric('public_usernames', str(len(set(usernames))))
                if data:
                    ctx.finding('medium', 'Public WordPress users exposed', f'Found {len(data)} public user records via wp-json.')
            else:
                diag.write_text('STATUS: NON_ARRAY_OR_BLOCKED\nREASON: Endpoint did not return a public users array.\n', encoding='utf-8')
        except Exception as exc:
            diag.write_text(f'STATUS: ERROR\nREASON: {exc}\n', encoding='utf-8')
            ctx.event('users', 'error', error=str(exc))
        if self.config.get('enable_wpscan') and have('wpscan'):
            rc, out, err = run_command(['wpscan', '--url', base, '--no-update'], timeout=120)
            (ctx.outdir / 'wp' / 'wpscan.txt').write_text(out or err, encoding='utf-8', errors='ignore')
        ctx.event('users', 'finished')
