from __future__ import annotations
from pathlib import Path
import os
import socketserver
import threading
import webbrowser
from http.server import SimpleHTTPRequestHandler

def find_report_root(base: Path) -> Path:
    base = base.resolve()
    if (base / 'reports' / 'report.html').exists():
        return base
    if (base / 'report.html').exists():
        return base.parent
    raise FileNotFoundError(f'Could not find report.html under: {base}')

def serve_dashboard(path: str, port: int = 8765, open_browser: bool = True) -> tuple[Path, str]:
    root = find_report_root(Path(path))
    reports_dir = (root / 'reports').resolve()
    os.chdir(reports_dir)

    class QuietHandler(SimpleHTTPRequestHandler):
        def log_message(self, format, *args):
            return

    httpd = socketserver.TCPServer(('127.0.0.1', int(port)), QuietHandler)
    url = f'http://127.0.0.1:{port}/report.html'
    if open_browser:
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    try:
        print(f'Serving dashboard from: {reports_dir}')
        print(f'Open: {url}')
        print('Press Ctrl+C to stop.')
        httpd.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        httpd.server_close()
    return reports_dir, url
