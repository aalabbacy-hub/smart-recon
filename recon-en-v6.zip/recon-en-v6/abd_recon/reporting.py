from __future__ import annotations
import json
from collections import Counter
from pathlib import Path
from .utils import escape, write_csv

SEVERITY_ORDER = ['critical', 'high', 'medium', 'low', 'info']

def _severity_counts(findings: list[dict]) -> dict[str, int]:
    c = Counter((f.get('severity') or 'info').lower() for f in findings)
    return {k: int(c.get(k, 0)) for k in SEVERITY_ORDER}

def _read_events(path: Path) -> list[dict]:
    if not path.exists():
        return []
    items = []
    for line in path.read_text(encoding='utf-8', errors='ignore').splitlines():
        line = line.strip()
        if not line:
            continue
        try:
            items.append(json.loads(line))
        except Exception:
            continue
    return items

def generate_reports(ctx) -> None:
    findings = [dict(severity=a, title=b, evidence=c) for a,b,c in ctx.store.list_rows('select severity,title,evidence from findings')]
    urls = [dict(url=a, status=b, title=c, tech=d) for a,b,c,d in ctx.store.list_rows('select url,status,title,tech from urls order by url')]
    users = [dict(username=a, display_name=b, link=c) for a,b,c in ctx.store.list_rows('select username,display_name,link from users')]
    subdomains = [a for (a,) in ctx.store.list_rows('select name from subdomains order by name')]
    events = _read_events(ctx.events_path)
    sev = _severity_counts(findings)
    metrics = {
        'subdomains': len(subdomains),
        'alive_urls': len(urls),
        'public_usernames': len({u['username'] for u in users if u['username']}),
        'profile': next((v for (v,) in ctx.store.list_rows("select v from metrics where k='profile'")), 'unknown'),
        'critical_findings': sev['critical'],
        'high_findings': sev['high'],
        'medium_findings': sev['medium'],
        'low_findings': sev['low'],
        'info_findings': sev['info'],
        'events': len(events),
    }
    for k, v in metrics.items():
        ctx.store.set_metric(k, str(v))

    summary = [
        'Recon Summary',
        '=============',
        f'Target Input: {ctx.target_input}',
        f'Target Kind: {ctx.target_kind}',
        f'Normalized Target: {ctx.normalized_target}',
        f"Profile: {metrics['profile']}",
        '',
        f"Subdomains: {metrics['subdomains']}",
        f"Alive URLs: {metrics['alive_urls']}",
        f"Public Usernames: {metrics['public_usernames']}",
        f"Findings: C={metrics['critical_findings']} H={metrics['high_findings']} M={metrics['medium_findings']} L={metrics['low_findings']} I={metrics['info_findings']}",
        f"Events: {metrics['events']}",
        '',
        'Findings',
        '--------',
    ]
    if findings:
        summary.extend([f"[{f['severity']}] {f['title']} :: {f['evidence']}" for f in findings])
    else:
        summary.append('No notable findings recorded.')
    summary.extend(['', 'Key files', '---------'])
    for p in sorted([x for x in ctx.outdir.rglob('*') if x.is_file()]):
        summary.append(str(p))
    (ctx.outdir / 'reports' / 'summary.txt').write_text('\n'.join(summary), encoding='utf-8')

    if ctx.config.get('enable_json'):
        payload = {
            'tool': ctx.config['tool_name'],
            'version': ctx.config['version'],
            'target_input': ctx.target_input,
            'target_kind': ctx.target_kind,
            'normalized_target': ctx.normalized_target,
            'metrics': metrics,
            'findings': findings,
            'urls': urls,
            'users': users,
            'subdomains': subdomains,
            'events': events,
        }
        (ctx.outdir / 'reports' / 'report.json').write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding='utf-8')

    if ctx.config.get('enable_csv'):
        write_csv(ctx.outdir / 'reports' / 'metrics.csv', [{'metric': k, 'value': v} for k, v in metrics.items()])
        if urls:
            write_csv(ctx.outdir / 'reports' / 'alive_urls.csv', urls)
        if users:
            write_csv(ctx.outdir / 'reports' / 'users.csv', users)
        if findings:
            write_csv(ctx.outdir / 'reports' / 'findings.csv', findings)

    if ctx.config.get('enable_html'):
        rows_findings = ''.join(
            f"<tr data-sev='{escape((f['severity'] or 'info').lower())}'><td><span class='sev {(f['severity'] or 'info').lower()}'>{escape(f['severity'])}</span></td><td>{escape(f['title'])}</td><td>{escape(f['evidence'])}</td></tr>"
            for f in findings
        ) or "<tr><td colspan='3'>No notable findings recorded.</td></tr>"

        rows_urls = ''.join(
            f"<tr><td><a href='{escape(u['url'])}' target='_blank' rel='noreferrer'>{escape(u['url'])}</a></td><td>{escape(str(u['status']))}</td><td>{escape(u['title'])}</td><td>{escape(u['tech'])}</td></tr>"
            for u in urls
        ) or "<tr><td colspan='4'>No alive URLs recorded.</td></tr>"

        rows_users = ''.join(
            f"<tr><td>{escape(u['username'])}</td><td>{escape(u['display_name'])}</td><td>{escape(u['link'])}</td></tr>"
            for u in users
        ) or "<tr><td colspan='3'>No users recorded.</td></tr>"

        rows_subs = ''.join(
            f"<tr><td>{escape(name)}</td></tr>" for name in subdomains
        ) or "<tr><td>No subdomains recorded.</td></tr>"

        rows_events = ''.join(
            f"<div class='timeline-item'><div class='dot'></div><div><div class='event-phase'>{escape(str(e.get('phase', 'event')))}</div><div class='event-msg'>{escape(str(e.get('message', '')))}</div><div class='event-extra'>{escape(json.dumps({k:v for k,v in e.items() if k not in {'phase','message'}}, ensure_ascii=False))}</div></div></div>"
            for e in events
        ) or "<div class='empty'>No events recorded.</div>"

        html_doc = f"""<!doctype html>
<html lang='en'>
<head>
<meta charset='utf-8'>
<meta name='viewport' content='width=device-width, initial-scale=1'>
<title>Recon-EN v6 Dashboard</title>
<style>
:root {{
  --bg:#0b1220; --panel:#111827; --panel-2:#1f2937; --line:#243041; --text:#e5edf7; --muted:#94a3b8;
  --good:#22c55e; --blue:#60a5fa; --amber:#f59e0b; --red:#ef4444; --violet:#a78bfa;
}}
* {{ box-sizing:border-box; }}
body {{ margin:0; font-family:Inter,Arial,sans-serif; background:linear-gradient(180deg,#0b1220,#0f172a 35%,#0b1220); color:var(--text); }}
.wrap {{ max-width:1380px; margin:0 auto; padding:26px; }}
.hero {{ display:flex; justify-content:space-between; gap:18px; align-items:flex-start; margin-bottom:20px; }}
.hero-card {{ flex:1; background:rgba(17,24,39,.92); border:1px solid var(--line); border-radius:22px; padding:22px; box-shadow:0 16px 40px rgba(0,0,0,.25); }}
h1 {{ margin:0 0 8px; font-size:32px; }}
p, .muted {{ color:var(--muted); margin:6px 0; }}
.badge {{ display:inline-block; border:1px solid var(--line); padding:8px 12px; border-radius:999px; margin:6px 8px 0 0; background:#0f172a; }}
.grid {{ display:grid; grid-template-columns:repeat(5,minmax(0,1fr)); gap:14px; margin-bottom:20px; }}
.metric {{ background:rgba(17,24,39,.92); border:1px solid var(--line); border-radius:18px; padding:18px; }}
.metric .label {{ color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.08em; }}
.metric .value {{ font-size:28px; font-weight:700; margin-top:8px; }}
.metric .sub {{ color:var(--muted); margin-top:4px; font-size:12px; }}
.section {{ background:rgba(17,24,39,.92); border:1px solid var(--line); border-radius:22px; padding:20px; margin-bottom:18px; }}
.section h2 {{ margin:0 0 14px; font-size:20px; }}
.section-head {{ display:flex; justify-content:space-between; align-items:center; gap:12px; margin-bottom:12px; flex-wrap:wrap; }}
.filters button {{ border:1px solid var(--line); background:#0f172a; color:var(--text); padding:8px 10px; border-radius:12px; cursor:pointer; }}
.filters button.active {{ outline:2px solid var(--blue); }}
table {{ width:100%; border-collapse:collapse; overflow:hidden; }}
th,td {{ border-bottom:1px solid var(--line); padding:12px; text-align:left; vertical-align:top; }}
th {{ color:var(--muted); font-size:12px; text-transform:uppercase; letter-spacing:.08em; }}
tr:hover td {{ background:rgba(255,255,255,.02); }}
.sev {{ display:inline-block; padding:6px 10px; border-radius:999px; font-size:12px; font-weight:700; text-transform:uppercase; }}
.sev.critical {{ background:rgba(239,68,68,.15); color:#fca5a5; }}
.sev.high {{ background:rgba(248,113,113,.12); color:#fda4af; }}
.sev.medium {{ background:rgba(245,158,11,.12); color:#fcd34d; }}
.sev.low {{ background:rgba(96,165,250,.12); color:#93c5fd; }}
.sev.info {{ background:rgba(167,139,250,.12); color:#c4b5fd; }}
.two-col {{ display:grid; grid-template-columns:1.1fr .9fr; gap:18px; }}
.timeline-item {{ display:flex; gap:12px; padding:10px 0; border-bottom:1px solid var(--line); }}
.dot {{ width:10px; height:10px; border-radius:999px; background:var(--blue); margin-top:7px; flex:0 0 auto; }}
.event-phase {{ font-weight:700; text-transform:uppercase; font-size:12px; color:#bfdbfe; }}
.event-msg {{ margin-top:2px; }}
.event-extra {{ color:var(--muted); font-size:12px; margin-top:4px; word-break:break-word; }}
.kv {{ display:grid; grid-template-columns:180px 1fr; gap:10px; }}
.kv div {{ padding:8px 0; border-bottom:1px solid var(--line); }}
.search {{ min-width:240px; padding:10px 12px; border-radius:12px; border:1px solid var(--line); background:#0f172a; color:var(--text); }}
.empty {{ color:var(--muted); padding:14px 0; }}
.footer {{ text-align:center; color:var(--muted); font-size:12px; padding:10px 0 28px; }}
@media (max-width:1100px) {{ .grid{{grid-template-columns:repeat(2,minmax(0,1fr));}} .two-col{{grid-template-columns:1fr;}} }}
@media (max-width:700px) {{ .grid{{grid-template-columns:1fr;}} .kv{{grid-template-columns:1fr;}} h1{{font-size:24px;}} .wrap{{padding:16px;}} }}
</style>
</head>
<body>
<div class='wrap'>
  <div class='hero'>
    <div class='hero-card'>
      <h1>Recon-EN v6 Dashboard</h1>
      <p>Authorized recon and exposure validation report</p>
      <span class='badge'>Target: {escape(ctx.target_input)}</span>
      <span class='badge'>Kind: {escape(ctx.target_kind)}</span>
      <span class='badge'>Profile: {escape(str(metrics['profile']))}</span>
      <span class='badge'>Output: {escape(str(ctx.outdir))}</span>
    </div>
  </div>

  <div class='grid'>
    <div class='metric'><div class='label'>Subdomains</div><div class='value'>{metrics['subdomains']}</div><div class='sub'>Discovered names</div></div>
    <div class='metric'><div class='label'>Alive URLs</div><div class='value'>{metrics['alive_urls']}</div><div class='sub'>Reachable web targets</div></div>
    <div class='metric'><div class='label'>Public usernames</div><div class='value'>{metrics['public_usernames']}</div><div class='sub'>Enumerated users</div></div>
    <div class='metric'><div class='label'>Findings</div><div class='value'>{len(findings)}</div><div class='sub'>All severities</div></div>
    <div class='metric'><div class='label'>Events</div><div class='value'>{metrics['events']}</div><div class='sub'>Pipeline timeline items</div></div>
  </div>

  <div class='grid'>
    <div class='metric'><div class='label'>Critical</div><div class='value'>{metrics['critical_findings']}</div></div>
    <div class='metric'><div class='label'>High</div><div class='value'>{metrics['high_findings']}</div></div>
    <div class='metric'><div class='label'>Medium</div><div class='value'>{metrics['medium_findings']}</div></div>
    <div class='metric'><div class='label'>Low</div><div class='value'>{metrics['low_findings']}</div></div>
    <div class='metric'><div class='label'>Info</div><div class='value'>{metrics['info_findings']}</div></div>
  </div>

  <div class='two-col'>
    <div class='section'>
      <div class='section-head'>
        <h2>Findings</h2>
        <div class='filters'>
          <button class='active' data-filter='all'>All</button>
          <button data-filter='critical'>Critical</button>
          <button data-filter='high'>High</button>
          <button data-filter='medium'>Medium</button>
          <button data-filter='low'>Low</button>
          <button data-filter='info'>Info</button>
        </div>
      </div>
      <table id='findings-table'>
        <thead><tr><th>Severity</th><th>Title</th><th>Evidence</th></tr></thead>
        <tbody>{rows_findings}</tbody>
      </table>
    </div>

    <div class='section'>
      <h2>Run Timeline</h2>
      {rows_events}
    </div>
  </div>

  <div class='section'>
    <div class='section-head'>
      <h2>Alive URLs</h2>
      <input class='search' id='url-search' placeholder='Search URL, title, tech'>
    </div>
      <table id='urls-table'>
        <thead><tr><th>URL</th><th>Status</th><th>Title</th><th>Tech</th></tr></thead>
        <tbody>{rows_urls}</tbody>
      </table>
  </div>

  <div class='two-col'>
    <div class='section'>
      <h2>Subdomains</h2>
      <table><thead><tr><th>Name</th></tr></thead><tbody>{rows_subs}</tbody></table>
    </div>
    <div class='section'>
      <h2>Users</h2>
      <table><thead><tr><th>Username</th><th>Display name</th><th>Link</th></tr></thead><tbody>{rows_users}</tbody></table>
    </div>
  </div>

  <div class='section'>
    <h2>Session Metadata</h2>
    <div class='kv'>
      <div class='muted'>Tool</div><div>{escape(ctx.config['tool_name'])} {escape(ctx.config['version'])}</div>
      <div class='muted'>Target input</div><div>{escape(ctx.target_input)}</div>
      <div class='muted'>Target kind</div><div>{escape(ctx.target_kind)}</div>
      <div class='muted'>Normalized target</div><div>{escape(ctx.normalized_target)}</div>
      <div class='muted'>Profile</div><div>{escape(str(metrics['profile']))}</div>
      <div class='muted'>SQLite</div><div>{escape(str(ctx.outdir / 'meta' / 'results.sqlite'))}</div>
      <div class='muted'>JSON report</div><div>{escape(str(ctx.outdir / 'reports' / 'report.json'))}</div>
      <div class='muted'>Summary</div><div>{escape(str(ctx.outdir / 'reports' / 'summary.txt'))}</div>
    </div>
  </div>

  <div class='footer'>Recon-EN v6 • local dashboard report</div>
</div>

<script>
const filterButtons = document.querySelectorAll('[data-filter]');
const findingRows = document.querySelectorAll('#findings-table tbody tr');
filterButtons.forEach(btn => {{
  btn.addEventListener('click', () => {{
    filterButtons.forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
    const sev = btn.dataset.filter;
    findingRows.forEach(row => {{
      row.style.display = (sev === 'all' || row.dataset.sev === sev) ? '' : 'none';
    }});
  }});
}});
const urlSearch = document.getElementById('url-search');
if (urlSearch) {{
  urlSearch.addEventListener('input', () => {{
    const q = urlSearch.value.toLowerCase();
    document.querySelectorAll('#urls-table tbody tr').forEach(row => {{
      const text = row.innerText.toLowerCase();
      row.style.display = text.includes(q) ? '' : 'none';
    }});
  }});
}}
</script>
</body>
</html>"""
        (ctx.outdir / 'reports' / 'report.html').write_text(html_doc, encoding='utf-8')
