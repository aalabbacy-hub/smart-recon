from __future__ import annotations
import sys
from pathlib import Path
from .config import load_config
from .recon import ReconApp
from .reporting import generate_reports
from .dashboard import serve_dashboard

BASE_DIR = Path(__file__).resolve().parent.parent

def prompt(msg: str) -> str:
    return input(msg).strip()

def show_summary(path: Path) -> None:
    print(f"\nResults: {path}")
    ans = prompt("Open summary now? (y/n): ")
    if ans.lower() == 'y':
        summary = path / 'reports' / 'summary.txt'
        if summary.exists():
            print("\n" + summary.read_text(encoding='utf-8', errors='ignore'))

def interactive_menu(app: ReconApp):
    while True:
        print(app.banner())
        print("What do you want?")
        print("1) Full scan")
        print("2) Passive only")
        print("3) Active only")
        print("4) Users diagnostic")
        print("5) Dependency check")
        print("6) Scan scope file")
        print("7) Open local dashboard")
        print("0) Exit")
        choice = prompt("Enter choice: ")
        if choice == '0':
            return
        if choice == '5':
            print("\nDependencies")
            print("------------")
            for tool, ok in app.dependency_report():
                print(f"[{'OK' if ok else '--'}] {tool}")
            input("\nPress Enter...")
            continue
        if choice == '7':
            report_path = prompt("Enter result folder path: ")
            if not report_path:
                print("No path entered")
                input("Press Enter...")
                continue
            try:
                serve_dashboard(report_path)
            except Exception as exc:
                print(f"Error: {exc}")
                input("Press Enter...")
            continue

        target = prompt("Enter target or scope file path: ")
        if not target:
            print("No target entered")
            continue
        try:
            if choice == '1':
                ctx = app.scan(target)
                show_summary(ctx.outdir)
            elif choice == '2':
                ctx = app.create_session(target)
                app.run_passive(ctx)
                generate_reports(ctx)
                show_summary(ctx.outdir)
            elif choice == '3':
                ctx = app.create_session(target)
                app.run_active(ctx)
                generate_reports(ctx)
                show_summary(ctx.outdir)
            elif choice == '4':
                ctx = app.create_session(target)
                app.run_active(ctx)
                app.run_users(ctx)
                generate_reports(ctx)
                show_summary(ctx.outdir)
            elif choice == '6':
                root = app.scan_scope_file(target)
                print(f"Batch results: {root}")
            else:
                print("Invalid choice")
        except Exception as exc:
            print(f"Error: {exc}")
            input("Press Enter...")

def main(argv: list[str] | None = None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    config = load_config(BASE_DIR)
    app = ReconApp(BASE_DIR, config)
    if not argv or argv[0] == 'menu':
        interactive_menu(app)
        return 0
    cmd = argv[0]
    if cmd in {'-h', '--help', 'help'}:
        print(app.banner())
        print('Usage:')
        print(f"  {config['tool_cmd']} scan <domain|url|ip|email|scope-file>")
        print(f"  {config['tool_cmd']} passive <target>")
        print(f"  {config['tool_cmd']} active <target>")
        print(f"  {config['tool_cmd']} users <target>")
        print(f"  {config['tool_cmd']} deps")
        print(f"  {config['tool_cmd']} dashboard <result-folder> [port]")
        print(f"  {config['tool_cmd']} menu")
        return 0
    if cmd == 'deps':
        print(app.banner())
        for tool, ok in app.dependency_report():
            print(f"[{'OK' if ok else '--'}] {tool}")
        return 0
    if cmd == 'dashboard':
        if len(argv) < 2:
            print('Result folder path required')
            return 1
        path = argv[1]
        port = int(argv[2]) if len(argv) > 2 else 8765
        serve_dashboard(path, port=port)
        return 0
    if len(argv) < 2:
        print('Target required')
        return 1
    target = argv[1]
    if cmd == 'scan':
        kind = app.create_session(target).target_kind
        if kind == 'file':
            batch = app.scan_scope_file(target)
            print(app.banner())
            print(f'Batch results: {batch}')
            return 0
        ctx = app.scan(target)
    elif cmd == 'passive':
        ctx = app.create_session(target)
        app.run_passive(ctx)
        generate_reports(ctx)
    elif cmd == 'active':
        ctx = app.create_session(target)
        app.run_active(ctx)
        generate_reports(ctx)
    elif cmd == 'users':
        ctx = app.create_session(target)
        app.run_active(ctx)
        app.run_users(ctx)
        generate_reports(ctx)
    else:
        print(f'Unknown command: {cmd}')
        return 1
    print(app.banner())
    print(f'Results: {ctx.outdir}')
    return 0

if __name__ == '__main__':
    raise SystemExit(main())
