from __future__ import annotations
from pathlib import Path
from hashlib import sha256
import json
import time

class FileCache:
    def __init__(self, cache_dir: Path, ttl_seconds: int = 21600):
        self.cache_dir = cache_dir
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        self.ttl_seconds = ttl_seconds

    def _path(self, key: str) -> Path:
        return self.cache_dir / (sha256(key.encode('utf-8')).hexdigest() + '.json')

    def get(self, key: str):
        path = self._path(key)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding='utf-8'))
        except Exception:
            return None
        ts = float(data.get('_ts', 0))
        if time.time() - ts > self.ttl_seconds:
            return None
        return data.get('value')

    def set(self, key: str, value):
        path = self._path(key)
        payload = {'_ts': time.time(), 'value': value}
        path.write_text(json.dumps(payload, ensure_ascii=False), encoding='utf-8')
