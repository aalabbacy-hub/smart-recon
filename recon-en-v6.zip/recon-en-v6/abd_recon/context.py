from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from datetime import datetime
from .store import Store
from .utils import jsonl_append, safe_slug

@dataclass
class SessionContext:
    base_dir: Path
    config: dict
    target_input: str
    target_kind: str
    normalized_target: str
    base_url: str | None
    timestamp: str = field(default_factory=lambda: datetime.now().strftime('%Y-%m-%d_%H-%M-%S'))

    def __post_init__(self):
        self.outdir = self.base_dir / self.config['outbase'] / f"{safe_slug(self.normalized_target)}_{self.timestamp}"
        self.events_path = self.outdir / 'meta' / 'events.jsonl'
        for sub in ['input','dns','subs','web','wp','osint','hosts','reports','logs','meta']:
            (self.outdir / sub).mkdir(parents=True, exist_ok=True)
        self.store = Store(self.outdir / 'meta' / 'results.sqlite')
        for k, v in {
            'target_input': self.target_input,
            'target_kind': self.target_kind,
            'normalized_target': self.normalized_target,
            'timestamp': self.timestamp,
        }.items():
            self.store.set_meta(k, str(v))

    def event(self, phase: str, message: str, **extra):
        obj = {'phase': phase, 'message': message, **extra}
        jsonl_append(self.events_path, obj)

    def finding(self, severity: str, title: str, evidence: str):
        self.store.add_finding(severity, title, evidence)
        self.event('finding', title, severity=severity, evidence=evidence)
